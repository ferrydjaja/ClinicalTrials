//UI5 Boilerplate Configuration
jQuery.sap.declare("app.config");

app.config = {
	//Navigation Mode (LaunchpadMode: false -> LeftMenu Navigation)
    LaunchpadMode: true

};