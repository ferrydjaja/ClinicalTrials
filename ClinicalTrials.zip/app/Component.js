jQuery.sap.declare("app.Component");

jQuery.sap.require("sap.ui.model.resource.ResourceModel");

sap.ui.core.UIComponent.extend("app.Component", {

    createContent: function() {

        // we keep it for your project specific usage

    }
});